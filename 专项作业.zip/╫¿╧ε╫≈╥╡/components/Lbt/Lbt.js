// components/Lbt/Lbt.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    imgList: [{
      imagePath: "../../images/1.jpeg",
      pagePath: "/pages/calc/calc"
    }, {
        imagePath: "../../images/2.jpg",
      pagePath: "/pages/lxjsq/lxjsq"
    }, {
        imagePath: "../../images/3.jpg",
      pagePath: "/pages/lxjsq/lxjsq"
    }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
