// components/LinkList/LinkList.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    ItemList:[
      {
        "pagename":"WXML学习的基本语法",
        "pagetext":"../index/index"
      },
      {
        "pagename": "利息计算机",
        "pagetext": "../lxjsq/lxjsq"
      },
      {
        "pagename":"扫描二维码",
        "pagetext": "../sm/sm"
      }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
